"""
Prediction-parity test: compares raw XGBoost predictions against the
converted CoreML model's predictions on the same input rows.

IMPORTANT: coremltools' .predict() only works on macOS (it calls into the
CoreML framework). This script will not run in a Linux container — run it
on your Mac after converting the model there (or after copying the
.mlmodel + your XGBoost model over).

Usage:
    python3 parity_test.py
"""

import numpy as np
import coremltools as ct
from convert_model import train_placeholder_model, FEATURE_NAMES, OUTPUT_PATH

TOLERANCE = 1e-3  # acceptable absolute difference between the two models' scores


def run_parity_test():
    # --- regenerate the same model + data used at conversion time ---
    # When you swap in your real trained model, replace this with:
    #   xgb_model = <your loaded/trained XGBClassifier>
    #   X_test = <held-out rows from your real dataset>
    xgb_model, X, y = train_placeholder_model(FEATURE_NAMES)
    X_test = X[:50]  # held-out-style sample; swap for a real held-out set later

    # --- original model predictions ---
    xgb_probs = xgb_model.predict_proba(X_test)[:, 1]

    # --- CoreML model predictions ---
    coreml_model = ct.models.MLModel(OUTPUT_PATH)
    coreml_probs = []
    for row in X_test:
        input_dict = {name: float(val) for name, val in zip(FEATURE_NAMES, row)}
        result = coreml_model.predict(input_dict)
        # classProbability is a dict like {0: p0, 1: p1} for classifiers
        coreml_probs.append(result["classProbability"][1])
    coreml_probs = np.array(coreml_probs)

    # --- compare ---
    diffs = np.abs(xgb_probs - coreml_probs)
    max_diff = diffs.max()
    mismatches = np.where(diffs > TOLERANCE)[0]

    print(f"Tested {len(X_test)} rows")
    print(f"Max absolute difference: {max_diff:.6f}")
    print(f"Tolerance: {TOLERANCE}")
    print(f"Rows exceeding tolerance: {len(mismatches)}")

    if len(mismatches) > 0:
        print("\nMismatched rows:")
        for i in mismatches:
            print(f"  row {i}: xgb={xgb_probs[i]:.4f}  coreml={coreml_probs[i]:.4f}  diff={diffs[i]:.4f}")
        print("\nRESULT: FAIL — investigate before shipping this model.")
    else:
        print("\nRESULT: PASS — CoreML predictions match XGBoost within tolerance.")

    return {
        "max_diff": float(max_diff),
        "n_mismatches": int(len(mismatches)),
        "tolerance": TOLERANCE,
        "n_tested": len(X_test),
    }


if __name__ == "__main__":
    run_parity_test()
