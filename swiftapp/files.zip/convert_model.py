"""
Converts a fraud model to CoreML format for the SwiftUI app.

PLACEHOLDER MODE (default): trains a small XGBoost classifier on random data,
with the exact same feature schema your real Project 1 model will use — and
using XGBoost itself (not a stand-in algorithm), so the conversion path you
test now is the *exact* path you'll use for the real model later.

SWAP-IN LATER: once your XGBoost model from Project 1 is trained, replace
`train_placeholder_model()` with a load of your real trained model
(`xgb.Booster().load_model(...)` or your sklearn-wrapper `.get_booster()`),
keep FEATURE_NAMES identical, and re-run. Nothing downstream (Swift code)
needs to change as long as feature names/order stay the same.
"""

import numpy as np
import coremltools as ct
import xgboost as xgb

# ---------------------------------------------------------------------------
# SCHEMA — locked contract between Project 1 (model) and Project 2 (app).
# Edit this list to match your real feature set from the fraud-lambda
# pipeline, then re-run this script. Order matters — must match training order.
# ---------------------------------------------------------------------------
FEATURE_NAMES = [
    "click_velocity",        # clicks per device/IP in sliding window
    "fingerprint_entropy",   # device/IP fingerprint entropy
    "click_to_conv_ratio",   # click-to-conversion ratio for campaign/publisher
    "geo_mismatch",          # 1 if geo-IP doesn't match device locale, else 0
    "time_to_click_ms",      # time between ad impression and click
    "ip_reuse_rate",         # how often this IP appears across recent clicks
]

OUTPUT_PATH = "FraudModel.mlmodel"


def train_placeholder_model(feature_names, n_samples: int = 500, seed: int = 42):
    """Small real XGBoost model on synthetic data — same algorithm/library
    you'll use for real, just fake data. Replace with your trained model
    when Project 1 is done (see module docstring)."""
    rng = np.random.default_rng(seed)
    n_features = len(feature_names)
    X = rng.random((n_samples, n_features))
    y = (X[:, 0] * 0.6 + X[:, 1] * 0.4 + rng.normal(0, 0.1, n_samples) > 0.5).astype(int)

    model = xgb.XGBClassifier(
        n_estimators=20,
        max_depth=3,
        eval_metric="logloss",
    )
    model.fit(X, y)
    return model, X, y


def convert_to_coreml(sk_model, feature_names, output_path):
    booster = sk_model.get_booster()
    booster.feature_names = feature_names
    coreml_model = ct.converters.xgboost.convert(
        booster,
        feature_names=feature_names,
        mode="classifier",
        class_labels=[0, 1],
    )
    coreml_model.author = "Shivank"
    coreml_model.short_description = "Ad-click fraud risk classifier (placeholder — swap for trained model)"
    coreml_model.save(output_path)
    print(f"Saved CoreML model to {output_path}")
    return coreml_model


if __name__ == "__main__":
    model, X, y = train_placeholder_model(FEATURE_NAMES)
    convert_to_coreml(model, FEATURE_NAMES, OUTPUT_PATH)

    # quick sanity check: print a few placeholder predictions
    probs = model.predict_proba(X[:5])[:, 1]
    print("Sample placeholder fraud probabilities:", np.round(probs, 3))
