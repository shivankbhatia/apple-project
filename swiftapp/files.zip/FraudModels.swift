import Foundation

/// A batch of ad clicks flagged for review, with the feature values
/// that fed the fraud model. Feature order here MUST match FEATURE_NAMES
/// in convert_model.py exactly — that's the contract between the two sides.
struct ClickBatch: Identifiable {
    let id: UUID
    let campaignName: String
    let publisherName: String
    let clickVelocity: Double
    let fingerprintEntropy: Double
    let clickToConvRatio: Double
    let geoMismatch: Double      // 1.0 or 0.0
    let timeToClickMs: Double
    let ipReuseRate: Double

    /// Feature vector in the exact order the model expects.
    var featureVector: [Double] {
        [clickVelocity, fingerprintEntropy, clickToConvRatio,
         geoMismatch, timeToClickMs, ipReuseRate]
    }
}

enum RiskLevel: String {
    case low = "Low"
    case medium = "Medium"
    case high = "High"

    static func from(score: Double) -> RiskLevel {
        switch score {
        case ..<0.3: return .low
        case 0.3..<0.7: return .medium
        default: return .high
        }
    }
}

/// Mock data so the UI is testable before you wire in real exported batches
/// from Project 1. Replace `ClickBatch.mockData` with a loader that reads
/// your exported CSV/JSON once Project 1's pipeline output is ready.
extension ClickBatch {
    static let mockData: [ClickBatch] = [
        ClickBatch(id: UUID(), campaignName: "Summer Sale", publisherName: "AdNet A",
                   clickVelocity: 0.82, fingerprintEntropy: 0.15, clickToConvRatio: 0.01,
                   geoMismatch: 1.0, timeToClickMs: 120, ipReuseRate: 0.91),
        ClickBatch(id: UUID(), campaignName: "App Install Push", publisherName: "AdNet B",
                   clickVelocity: 0.12, fingerprintEntropy: 0.78, clickToConvRatio: 0.34,
                   geoMismatch: 0.0, timeToClickMs: 4200, ipReuseRate: 0.08),
        ClickBatch(id: UUID(), campaignName: "Holiday Promo", publisherName: "AdNet C",
                   clickVelocity: 0.55, fingerprintEntropy: 0.40, clickToConvRatio: 0.12,
                   geoMismatch: 0.0, timeToClickMs: 900, ipReuseRate: 0.45),
    ]
}
